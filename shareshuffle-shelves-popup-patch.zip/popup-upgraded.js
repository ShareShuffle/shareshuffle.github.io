console.log("ShareShuffle popup loaded");

const FIREBASE_PROJECT_ID = "shareshuffle-c7f96";
const FIRESTORE_COLLECTION = "shares";
const SHELVES_COLLECTION = "shelves";
const SHARE_BASE_URL = "https://shfl.me/";
const SHELF_BASE_URL = "https://shareshuffle.com/shelf.html?s=";

const FIRESTORE_URL =
  `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${FIRESTORE_COLLECTION}`;

const SHELVES_URL =
  `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${SHELVES_COLLECTION}`;

function makeShortId(length = 5) {
  const chars = "23456789abcdefghjklmnpqrstuvwxyz";
  let id = "";

  for (let i = 0; i < length; i++) {
    id += chars[Math.floor(Math.random() * chars.length)];
  }

  return id;
}

function makeSlug(value = "") {
  return value
    .toLowerCase()
    .trim()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .substring(0, 48);
}

async function shareExists(id) {
  const response = await fetch(`${FIRESTORE_URL}/${id}`);
  return response.ok;
}

async function createUniqueId() {
  let id;

  do {
    id = makeShortId();
  } while (await shareExists(id));

  return id;
}

async function getCurrentTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });

  console.log("tabs query result:", tabs);

  return tabs[0];
}

async function getProductImage(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const image =
        document.querySelector("#landingImage")?.src ||
        document.querySelector("#imgBlkFront")?.src ||
        document.querySelector('meta[property="og:image"]')?.content ||
        document.querySelector('meta[name="twitter:image"]')?.content ||
        "";

      return image;
    }
  });

  return results?.[0]?.result || "";
}

async function createShelfIfNeeded(shelfName) {
  const cleanName = shelfName.trim();

  if (!cleanName) {
    return { shelfName: "", shelfSlug: "", shelfUrl: "" };
  }

  const shelfSlug = makeSlug(cleanName);
  const shelfUrl = `${SHELF_BASE_URL}${encodeURIComponent(shelfSlug)}`;

  if (!shelfSlug) {
    return { shelfName: "", shelfSlug: "", shelfUrl: "" };
  }

  const body = {
    fields: {
      name: { stringValue: cleanName },
      slug: { stringValue: shelfSlug },
      created: { timestampValue: new Date().toISOString() }
    }
  };

  const response = await fetch(`${SHELVES_URL}?documentId=${encodeURIComponent(shelfSlug)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  // Firestore returns 409 if the shelf already exists. That is fine.
  if (!response.ok && response.status !== 409) {
    const errorText = await response.text();
    throw new Error(errorText);
  }

  return { shelfName: cleanName, shelfSlug, shelfUrl };
}

async function createShareDocument(id, data) {
  const url = `${FIRESTORE_URL}?documentId=${id}`;

  const body = {
    fields: {
      title: { stringValue: data.title || "" },
      url: { stringValue: data.url || "" },
      note: { stringValue: data.note || "" },
      image: { stringValue: data.image || "" },
      shelfName: { stringValue: data.shelfName || "" },
      shelfSlug: { stringValue: data.shelfSlug || "" },
      created: { timestampValue: new Date().toISOString() },
      views: { integerValue: 0 },
      amazonClicks: { integerValue: 0 },
      shares: { integerValue: 0 }
    }
  };

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText);
  }

  return response.json();
}

function buildMessage({ note, shareUrl }) {
  return [
    note || "I saw this and thought of you.",
    "",
    shareUrl,
    "",
    "Shared with ShareShuffle"
  ].join("\n");
}

document.addEventListener("DOMContentLoaded", async () => {
  const titleInput = document.getElementById("title");
  const urlInput = document.getElementById("url");
  const noteInput = document.getElementById("note");
  const shelfNameInput = document.getElementById("shelfName");
  const copyBtn = document.getElementById("copyBtn");
  const copyLinkBtn = document.getElementById("copyLinkBtn");
  const emailBtn = document.getElementById("emailBtn");
  const textBtn = document.getElementById("textBtn");
  const voiceBtn = document.getElementById("voiceBtn");
  const actions = document.getElementById("actions");
  const shelfActions = document.getElementById("shelfActions");
  const openShelf = document.getElementById("openShelf");
  const status = document.getElementById("status");

  let lastShareUrl = "";
  let lastMessage = "";

  const tab = await getCurrentTab();

  titleInput.value = tab?.title || "";
  urlInput.value = tab?.url || "";

  copyBtn.addEventListener("click", async () => {
    try {
      status.textContent = "Creating share link...";
      copyBtn.disabled = true;

      const id = await createUniqueId();
      const image = await getProductImage(tab.id);
      const shelf = await createShelfIfNeeded(shelfNameInput.value || "");

      await createShareDocument(id, {
        title: titleInput.value,
        url: urlInput.value,
        note: noteInput.value,
        image,
        shelfName: shelf.shelfName,
        shelfSlug: shelf.shelfSlug
      });

      const shareUrl = `${SHARE_BASE_URL}${id}`;
      const message = buildMessage({
        note: noteInput.value,
        shareUrl
      });

      lastShareUrl = shareUrl;
      lastMessage = message;

      await navigator.clipboard.writeText(message);

      actions.style.display = "grid";
      status.textContent = `Copied: ${id}`;

      if (shelf.shelfUrl) {
        openShelf.href = shelf.shelfUrl;
        shelfActions.style.display = "block";
      } else {
        shelfActions.style.display = "none";
      }
    } catch (error) {
      console.error(error);
      status.textContent = "Error. Check console.";
    } finally {
      copyBtn.disabled = false;
    }
  });

  copyLinkBtn.addEventListener("click", async () => {
    if (!lastShareUrl) return;
    await navigator.clipboard.writeText(lastShareUrl);
    status.textContent = "Short link copied.";
  });

  emailBtn.addEventListener("click", () => {
    if (!lastMessage) return;

    const subject = encodeURIComponent("I saw this and thought of you");
    const body = encodeURIComponent(lastMessage);

    window.open(`mailto:?subject=${subject}&body=${body}`);
  });

  textBtn.addEventListener("click", () => {
    if (!lastMessage) return;

    const body = encodeURIComponent(lastMessage);
    window.open(`sms:?&body=${body}`);
  });

  voiceBtn.addEventListener("click", async () => {
    if (!lastMessage) return;

    await navigator.clipboard.writeText(lastMessage);
    window.open("https://voice.google.com/u/0/messages", "_blank");
    status.textContent = "Copied and opened Google Voice.";
  });
});
